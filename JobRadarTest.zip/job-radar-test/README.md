# 🧪 JobRadarTest - Versión Demo

Versión de demostración de Job Radar para pruebas y evaluación.

## ✨ Características

- **Sin login requerido** - Acceso directo al dashboard
- **Sin límites de uso** - Todas las funciones disponibles
- **Configuración sencilla** - Solo necesitas tu API key

## 🚀 Inicio rápido

```bash
# Instalar dependencias
npm install

# Iniciar servidor
npm start
```

Abre http://localhost:3000 en tu navegador.

## ⚙️ Configuración inicial

1. Al abrir la app, verás el overlay de configuración
2. Selecciona tu proveedor de IA (Anthropic o OpenAI)
3. Introduce tu API key
4. ¡Listo para usar!

## 🔧 Funciones incluidas

| Función | Descripción |
|---------|-------------|
| 🔍 Buscar ofertas | Búsqueda inteligente en múltiples portales |
| 🔗 Evaluar por URL | Analiza ofertas específicas |
| ✨ Mejorar CV | Optimiza tu CV con IA |
| 🎯 Asesor de Carrera | Análisis de brechas y roadmap |
| 🎤 Simulador Entrevista | Preguntas personalizadas |

## 📋 Requisitos

- Node.js 18+
- API key de Anthropic (Claude) o OpenAI (GPT-4)

## ⚠️ Aviso

Esta es una versión de demostración. Para uso en producción con autenticación y planes de pago, contacta con el desarrollador.

---
© 2024 JobRadar
