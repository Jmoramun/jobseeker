/**
 * JobRadarTest - Versión de demostración sin autenticación
 * Solo para pruebas y evaluación
 */

const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.static('public'));

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// ══════════════════════════════════════════════════════════════════════════════
// CONFIGURATION
// ══════════════════════════════════════════════════════════════════════════════

const CONFIG_PATH = path.join('data', 'config.json');
const CV_STORE = new Map();

function getConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    }
  } catch (e) { console.error('Config read error:', e.message); }
  return null;
}

function saveConfig(cfg) {
  fs.mkdirSync('data', { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

function isConfigured() {
  const cfg = getConfig();
  return cfg && cfg.provider && cfg.apiKey;
}

// ══════════════════════════════════════════════════════════════════════════════
// CV TOKEN SYSTEM
// ══════════════════════════════════════════════════════════════════════════════

function storeCvBuffer(buf) {
  const token = crypto.randomBytes(16).toString('hex');
  CV_STORE.set(token, { buffer: buf, ts: Date.now() });
  return token;
}

function getCvFromToken(token) {
  const entry = CV_STORE.get(token);
  return entry ? entry.buffer : null;
}

function getCvBuffer(req) {
  if (req.file) return req.file.buffer;
  if (req.body.cv_token) return getCvFromToken(req.body.cv_token);
  return null;
}

// Cleanup old CVs every 30 minutes
setInterval(() => {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [token, entry] of CV_STORE.entries()) {
    if (entry.ts < cutoff) CV_STORE.delete(token);
  }
}, 30 * 60 * 1000);

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - CONFIG
// ══════════════════════════════════════════════════════════════════════════════

app.get('/api/config', (req, res) => {
  const cfg = getConfig();
  if (!cfg) return res.json({ configured: false });
  res.json({
    configured: true,
    provider: cfg.provider,
    model: cfg.model,
    hasKey: !!cfg.apiKey
  });
});

app.post('/api/config', (req, res) => {
  const { provider, apiKey, model } = req.body;
  if (!provider || !apiKey) {
    return res.status(400).json({ error: 'Provider y API Key son obligatorios' });
  }
  
  const cfg = getConfig() || {};
  cfg.provider = provider;
  cfg.apiKey = apiKey;
  cfg.model = model || (provider === 'anthropic' ? 'claude-sonnet-4-20250514' : 'gpt-4o');
  saveConfig(cfg);
  
  res.json({ ok: true, configured: true });
});

app.post('/api/config/test', async (req, res) => {
  const { provider, apiKey, model } = req.body;
  const ai = require('./lib/ai');
  
  try {
    // Save config temporarily to test
    const oldCfg = getConfig();
    const testCfg = { provider, apiKey, model };
    saveConfig(testCfg);
    
    // Simple test call
    const result = await ai.callAI({
      maxTokens: 50,
      system: 'Responde solo con "OK"',
      prompt: 'Test de conexión'
    });
    
    // Restore old config if test was just a test
    if (oldCfg) saveConfig(oldCfg);
    
    res.json({ ok: true, response: result.slice(0, 100) });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - CV SESSION
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/cv-session', upload.single('cv'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'CV es obligatorio' });
  const token = storeCvBuffer(req.file.buffer);
  res.json({ token, filename: req.file.originalname });
});

app.get('/api/dashboard', (req, res) => {
  // Dashboard stats - demo version returns zeros
  res.json({
    searches: 0,
    topAplicar: 0,
    tracked: 0,
    interviewing: 0
  });
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - CV OPERATIONS
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/analyze-cv', upload.single('cv'), async (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  try {
    const { analyzeCV } = require('./lib/claude');
    const analysis = await analyzeCV(cvBuf);
    const token = storeCvBuffer(cvBuf);
    res.json({ ...analysis, cv_token: token });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - SEARCH
// ══════════════════════════════════════════════════════════════════════════════

const searches = new Map();

app.post('/api/search', upload.single('cv'), (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  // Parse config from frontend
  let cfg = {};
  try {
    cfg = req.body.config ? JSON.parse(req.body.config) : {};
  } catch(e) {
    cfg = {};
  }

  const searchId = crypto.randomUUID();
  const emitter = new EventEmitter();
  
  searches.set(searchId, { emitter, results: [], done: false, stats: { total: 0, aplicar: 0, revisar: 0, descartar: 0 } });
  
  // Start search in background
  setImmediate(async () => {
    try {
      const { analyzeCV, scoreJob } = require('./lib/claude');
      const { searchAllSources } = require('./lib/jobsources');
      
      emitter.emit('status', { step: 'ANALIZANDO', message: 'Analizando tu CV...', progress: 5 });
      
      const analysis = await analyzeCV(cvBuf);
      
      // Emit profile for frontend
      emitter.emit('profile', { perfil: analysis });
      emitter.emit('status', { step: 'CV ANALIZADO', message: `${analysis.nombre_completo || 'Perfil'} · ${analysis.anos_experiencia_total || 0} años exp.`, progress: 15 });
      
      const query = cfg.puestosRaw || cfg.puestos?.join(', ') || analysis.titulo_profesional || 'Developer';
      const location = cfg.ciudad || 'Madrid';
      const sources = cfg.sources || ['infojobs', 'linkedin', 'tecnoempleo'];
      
      emitter.emit('status', { step: 'BUSCANDO', message: `Buscando "${query}" en ${sources.join(', ')}...`, progress: 20 });
      
      // Build config for searchAllSources
      const searchCfg = {
        puestosRaw: query,
        ciudad: location,
        pais: cfg.pais || 'Spain',
        periodo: cfg.periodo || 'Última semana',
        sources: sources
      };
      
      console.log('[Search] Config:', JSON.stringify(searchCfg));
      const jobs = await searchAllSources(searchCfg);
      console.log('[Search] Found jobs:', jobs.length);
      
      // Emit jobs_found event
      emitter.emit('jobs_found', { count: jobs.length });
      
      if (jobs.length === 0) {
        emitter.emit('status', { 
          step: 'SIN RESULTADOS',
          message: 'No se encontraron ofertas. Prueba con "Evaluar por URL".', 
          progress: 100
        });
        searches.get(searchId).done = true;
        emitter.emit('complete', { total: 0, aplicar: 0, revisar: 0, descartar: 0 });
        return;
      }
      
      emitter.emit('status', { step: 'EVALUANDO', message: `Evaluando ${jobs.length} ofertas...`, progress: 30 });
      
      const searchData = searches.get(searchId);
      
      // Score jobs
      for (let i = 0; i < jobs.length; i++) {
        try {
          // Build scoring config from analysis and search params
          const scoreCfg = {
            perfil: analysis,
            salarioMin: parseInt(cfg.salarioMin) || 25000,
            ciudad: location,
            puestosRaw: query,
            priorities: cfg.priorities || { role: 8, salary: 7, location: 6, company: 5, skills: 7, growth: 5 }
          };
          const scored = await scoreJob(jobs[i], scoreCfg);
          const result = { ...jobs[i], ...scored };
          searchData.results.push(result);
          
          // Update stats
          searchData.stats.total++;
          if (result.recommendation === 'APLICAR') searchData.stats.aplicar++;
          else if (result.recommendation === 'REVISAR') searchData.stats.revisar++;
          else searchData.stats.descartar++;
          
          emitter.emit('job', result);
          
          // Update progress
          const pct = 30 + Math.round((i / jobs.length) * 65);
          emitter.emit('status', { step: 'EVALUANDO', message: `Evaluando oferta ${i+1} de ${jobs.length}...`, progress: pct });
        } catch (e) {
          console.error('Score error:', e.message);
        }
      }
      
      searchData.done = true;
      emitter.emit('complete', searchData.stats);
      
    } catch (e) {
      console.error('[Search] Error:', e.message);
      emitter.emit('error', { message: e.message });
    }
  });
  
  res.json({ searchId, cv_token: storeCvBuffer(cvBuf) });
});

app.get('/api/search/:id/stream', (req, res) => {
  const search = searches.get(req.params.id);
  if (!search) return res.status(404).json({ error: 'Search not found' });

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  
  // Send existing results
  search.results.forEach(r => send('job', r));
  if (search.done) { send('complete', search.stats || { total: search.results.length, aplicar: 0, revisar: 0, descartar: 0 }); return res.end(); }

  const onJob = (data) => send('job', data);
  const onStatus = (data) => send('status', data);
  const onProfile = (data) => send('profile', data);
  const onJobsFound = (data) => send('jobs_found', data);
  const onComplete = (data) => { send('complete', data); cleanup(); res.end(); };
  const onError = (data) => { send('error', data); cleanup(); res.end(); };
  
  const cleanup = () => {
    search.emitter.off('job', onJob);
    search.emitter.off('status', onStatus);
    search.emitter.off('profile', onProfile);
    search.emitter.off('jobs_found', onJobsFound);
    search.emitter.off('complete', onComplete);
    search.emitter.off('error', onError);
  };

  search.emitter.on('job', onJob);
  search.emitter.on('status', onStatus);
  search.emitter.on('profile', onProfile);
  search.emitter.on('jobs_found', onJobsFound);
  search.emitter.on('complete', onComplete);
  search.emitter.on('error', onError);
  
  req.on('close', cleanup);
});

// Alias for frontend compatibility
app.get('/api/stream/:id', (req, res) => {
  const search = searches.get(req.params.id);
  if (!search) return res.status(404).json({ error: 'Search not found' });

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  
  // Send existing results
  search.results.forEach(r => send('job', r));
  if (search.done) { send('complete', search.stats || { total: search.results.length, aplicar: 0, revisar: 0, descartar: 0 }); return res.end(); }

  const onJob = (data) => send('job', data);
  const onStatus = (data) => send('status', data);
  const onProfile = (data) => send('profile', data);
  const onJobsFound = (data) => send('jobs_found', data);
  const onComplete = (data) => { send('complete', data); cleanup(); res.end(); };
  const onError = (data) => { send('error', data); cleanup(); res.end(); };
  
  const cleanup = () => {
    search.emitter.off('job', onJob);
    search.emitter.off('status', onStatus);
    search.emitter.off('profile', onProfile);
    search.emitter.off('jobs_found', onJobsFound);
    search.emitter.off('complete', onComplete);
    search.emitter.off('error', onError);
  };

  search.emitter.on('job', onJob);
  search.emitter.on('status', onStatus);
  search.emitter.on('profile', onProfile);
  search.emitter.on('jobs_found', onJobsFound);
  search.emitter.on('complete', onComplete);
  search.emitter.on('error', onError);
  
  req.on('close', cleanup);
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - IMPROVE CV
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/improve-cv', upload.single('cv'), async (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  const template = req.body.template || 'executive';
  const sector = req.body.sector || 'all';
  const level = req.body.level || 'senior';
  const lang = req.body.lang || 'es';

  try {
    const { improveCV } = require('./lib/claude');
    const { makeCV } = require('./lib/cvtemplates');
    
    const improved = await improveCV(cvBuf, { sector, level, lang });
    const pdfBuf = makeCV(improved, template, { lang });

    const dir = path.join('data', 'cvs');
    fs.mkdirSync(dir, { recursive: true });
    const safe = s => (s || '').replace(/[^a-zA-Z0-9_\-\u00C0-\u024F]/g, '_').slice(0, 40);
    const langSuffix = lang === 'en' ? '_EN' : '';
    const filename = `CV_${safe(improved.nombre)}_${template}${langSuffix}.pdf`;
    fs.writeFileSync(path.join(dir, filename), pdfBuf);

    res.json({
      improved,
      downloadUrl: `/api/download-cv/${encodeURIComponent(filename)}`,
      filename
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/create-cv', async (req, res) => {
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  const { nombre, titulo, email, telefono, ubicacion, linkedin, resumen,
    experiencia, formacion, habilidades, idiomas, certificaciones,
    sector, level, lang, template, optimize } = req.body;

  if (!nombre || !titulo || !email || !resumen) {
    return res.status(400).json({ error: 'Faltan campos obligatorios' });
  }

  try {
    let cvData = { nombre, titulo, email, telefono, ubicacion, linkedin, resumen,
      experiencia: experiencia || [], formacion: formacion || [],
      habilidades: habilidades || [], idiomas: idiomas || [], certificaciones: certificaciones || [] };
    
    let optimizations = [];
    
    if (optimize) {
      const { optimizeCVData } = require('./lib/claude');
      const optimized = await optimizeCVData(cvData, { sector, level, lang });
      cvData = optimized.data;
      optimizations = optimized.optimizations || [];
    }
    
    const { makeCV } = require('./lib/cvtemplates');
    const pdfBuf = makeCV(cvData, template || 'executive', { lang: lang || 'es' });

    const dir = path.join('data', 'cvs');
    fs.mkdirSync(dir, { recursive: true });
    const safe = s => (s || '').replace(/[^a-zA-Z0-9_\-\u00C0-\u024F]/g, '_').slice(0, 40);
    const langSuffix = lang === 'en' ? '_EN' : '';
    const filename = `CV_${safe(nombre)}_${template || 'executive'}${langSuffix}.pdf`;
    fs.writeFileSync(path.join(dir, filename), pdfBuf);

    res.json({ ok: true, cvData, optimizations, downloadUrl: `/api/download-cv/${encodeURIComponent(filename)}`, filename });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/regenerate-cv', async (req, res) => {
  const { cvData, template, lang } = req.body;
  if (!cvData) return res.status(400).json({ error: 'cvData es obligatorio' });

  try {
    const { makeCV } = require('./lib/cvtemplates');
    const pdfBuf = makeCV(cvData, template || 'executive', { lang: lang || 'es' });

    const dir = path.join('data', 'cvs');
    fs.mkdirSync(dir, { recursive: true });
    const safe = s => (s || '').replace(/[^a-zA-Z0-9_\-\u00C0-\u024F]/g, '_').slice(0, 40);
    const langSuffix = lang === 'en' ? '_EN' : '';
    const filename = `CV_${safe(cvData.nombre)}_${template || 'executive'}${langSuffix}.pdf`;
    fs.writeFileSync(path.join(dir, filename), pdfBuf);

    res.json({ ok: true, downloadUrl: `/api/download-cv/${encodeURIComponent(filename)}`, filename });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/download-cv/:filename', (req, res) => {
  const filename = decodeURIComponent(req.params.filename);
  const filepath = path.resolve('data', 'cvs', filename);
  if (!filepath.startsWith(path.resolve('data', 'cvs')) || !fs.existsSync(filepath)) {
    return res.status(404).json({ error: 'Archivo no encontrado' });
  }
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
  res.sendFile(filepath);
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - GENERATE ADAPTED CV + COVER LETTER
// ══════════════════════════════════════════════════════════════════════════════

// Helper: Generate cover letter PDF
function makeCartaPDF(carta, job) {
  const PW = 595, PH = 842;
  const margin = 60;
  const lineH = 16;
  
  // Simple PDF generator for cover letter
  const enc = s => (s||'').replace(/[\(\)\\]/g, c => '\\' + c);
  const wrapText = (text, maxChars = 85) => {
    const words = (text || '').split(' ');
    const lines = [];
    let line = '';
    for (const w of words) {
      if ((line + ' ' + w).length > maxChars) {
        lines.push(line.trim());
        line = w;
      } else {
        line += ' ' + w;
      }
    }
    if (line.trim()) lines.push(line.trim());
    return lines;
  };
  
  let y = PH - margin;
  let content = '';
  
  // Header with date
  const fecha = new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
  content += `BT /F1 10 Tf ${margin} ${y} Td (${enc(fecha)}) Tj ET\n`;
  y -= lineH * 2;
  
  // Recipient
  content += `BT /F2 11 Tf ${margin} ${y} Td (${enc(job.company || 'Empresa')}) Tj ET\n`;
  y -= lineH;
  if (job.location) {
    content += `BT /F1 10 Tf ${margin} ${y} Td (${enc(job.location)}) Tj ET\n`;
    y -= lineH;
  }
  y -= lineH;
  
  // Subject
  content += `BT /F2 11 Tf ${margin} ${y} Td (Ref: Candidatura para ${enc(job.title || 'el puesto')}) Tj ET\n`;
  y -= lineH * 2;
  
  // Saludo
  content += `BT /F1 11 Tf ${margin} ${y} Td (${enc(carta.saludo || 'Estimado/a responsable de selección,')}) Tj ET\n`;
  y -= lineH * 2;
  
  // Paragraphs
  const paragraphs = [carta.parrafo1, carta.parrafo2, carta.parrafo3, carta.parrafo4].filter(Boolean);
  for (const p of paragraphs) {
    const lines = wrapText(p);
    for (const line of lines) {
      if (y < margin + 100) break; // Avoid overflow
      content += `BT /F1 10 Tf ${margin} ${y} Td (${enc(line)}) Tj ET\n`;
      y -= lineH;
    }
    y -= lineH * 0.5; // Extra space between paragraphs
  }
  
  y -= lineH;
  
  // Despedida
  content += `BT /F1 11 Tf ${margin} ${y} Td (${enc(carta.despedida || 'Atentamente,')}) Tj ET\n`;
  y -= lineH * 3;
  
  // Nombre
  content += `BT /F2 11 Tf ${margin} ${y} Td (${enc(carta.nombre || '')}) Tj ET\n`;
  
  // Build PDF
  const stream = content;
  const pdf = `%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >> endobj
4 0 obj << /Length ${stream.length} >> stream
${stream}
endstream endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
6 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> endobj
xref
0 7
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000270 00000 n 
0000000${String(270 + stream.length + 30).padStart(3, '0')} 00000 n 
0000000${String(270 + stream.length + 30 + 70).padStart(3, '0')} 00000 n 
trailer << /Size 7 /Root 1 0 R >>
startxref
${270 + stream.length + 30 + 70 + 75}
%%EOF`;
  
  return Buffer.from(pdf);
}

app.post('/api/generate-docs', upload.single('cv'), async (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  let job;
  try {
    job = typeof req.body.job === 'string' ? JSON.parse(req.body.job) : req.body.job;
  } catch(e) {
    return res.status(400).json({ error: 'Datos de oferta inválidos' });
  }
  
  if (!job || !job.title) {
    return res.status(400).json({ error: 'Datos de oferta incompletos' });
  }

  try {
    const { analyzeCV, generateDocs } = require('./lib/claude');
    const { makeCV } = require('./lib/cvtemplates');
    
    // Analyze CV to get profile
    const perfil = await analyzeCV(cvBuf);
    
    // Generate adapted docs
    const docs = await generateDocs(job, { perfil });
    
    const dir = path.join('data', 'docs');
    fs.mkdirSync(dir, { recursive: true });
    
    const safe = s => (s || '').replace(/[^a-zA-Z0-9_\-\u00C0-\u024F]/g, '_').slice(0, 30);
    const timestamp = Date.now();
    
    // Generate CV PDF
    const cvData = docs.cv_adaptado;
    const cvPdfBuf = makeCV(cvData, req.body.template || 'modern', { lang: 'es' });
    const cvFilename = `CV_${safe(cvData.nombre)}_${safe(job.company)}_${timestamp}.pdf`;
    fs.writeFileSync(path.join(dir, cvFilename), cvPdfBuf);
    
    // Generate Cover Letter PDF
    const cartaPdfBuf = makeCartaPDF(docs.carta, job);
    const cartaFilename = `Carta_${safe(cvData.nombre)}_${safe(job.company)}_${timestamp}.pdf`;
    fs.writeFileSync(path.join(dir, cartaFilename), cartaPdfBuf);
    
    res.json({
      ok: true,
      cvUrl: `/api/download-doc/${encodeURIComponent(cvFilename)}`,
      cartaUrl: `/api/download-doc/${encodeURIComponent(cartaFilename)}`,
      cvFilename,
      cartaFilename
    });
  } catch (e) {
    console.error('Generate docs error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/download-doc/:filename', (req, res) => {
  const filename = decodeURIComponent(req.params.filename);
  const filepath = path.resolve('data', 'docs', filename);
  if (!filepath.startsWith(path.resolve('data', 'docs')) || !fs.existsSync(filepath)) {
    return res.status(404).json({ error: 'Archivo no encontrado' });
  }
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
  res.sendFile(filepath);
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - ADVISOR
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/advisor', upload.single('cv'), async (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  const targetJob = (req.body.target_job || '').trim();
  const extraContext = (req.body.context || '').trim();
  if (!targetJob) return res.status(400).json({ error: 'target_job es obligatorio' });

  try {
    const { advisorCV } = require('./lib/claude');
    const { makeAdvisorPDF } = require('./lib/advisorpdf');
    
    const report = await advisorCV(cvBuf, targetJob, extraContext);
    report._targetJob = targetJob;
    
    // Asegurar que siempre hay mensaje_motivador para el frontend
    if (!report.mensaje_motivador && report.mensaje_final?.mensaje) {
      report.mensaje_motivador = report.mensaje_final.mensaje;
    }
    if (!report.mensaje_motivador && report.diagnostico_duro?.mensaje_directo) {
      report.mensaje_motivador = report.diagnostico_duro.mensaje_directo;
    }
    if (!report.mensaje_motivador) {
      report.mensaje_motivador = `Tu objetivo de alcanzar el puesto de ${targetJob} es ambicioso. Con el plan de acción adecuado y dedicación constante, puedes lograrlo. ¡El primer paso ya lo has dado!`;
    }

    const pdfBuf = makeAdvisorPDF(report);
    const dir = path.join('data', 'advisor');
    fs.mkdirSync(dir, { recursive: true });
    const safe = s => (s || '').replace(/[^a-zA-Z0-9_\-\u00C0-\u024F]/g, '_').slice(0, 30);
    const filename = `Advisor_${safe(report.candidato?.nombre || 'informe')}_${Date.now()}.pdf`;
    fs.writeFileSync(path.join(dir, filename), pdfBuf);

    res.json({ report, downloadUrl: `/api/download-advisor/${encodeURIComponent(filename)}`, filename });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/download-advisor/:filename', (req, res) => {
  const filename = decodeURIComponent(req.params.filename);
  const filepath = path.resolve('data', 'advisor', filename);
  if (!filepath.startsWith(path.resolve('data', 'advisor')) || !fs.existsSync(filepath)) {
    return res.status(404).json({ error: 'Archivo no encontrado' });
  }
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
  res.sendFile(filepath);
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - INTERVIEW SIMULATOR
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/interview/start', upload.single('cv'), async (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  const targetJob = (req.body.target_job || '').trim();
  const numQuestions = parseInt(req.body.num_questions) || 12;
  if (!targetJob) return res.status(400).json({ error: 'target_job es obligatorio' });

  try {
    const { interviewSimulator } = require('./lib/claude');
    const result = await interviewSimulator(cvBuf, targetJob, numQuestions);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES - EVALUATE URLs
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/evaluate-urls', upload.single('cv'), async (req, res) => {
  const cvBuf = getCvBuffer(req);
  if (!cvBuf) return res.status(400).json({ error: 'CV es obligatorio' });
  if (!isConfigured()) return res.status(503).json({ error: 'setup_required' });

  let urls = req.body.urls;
  if (typeof urls === 'string') urls = JSON.parse(urls);
  if (!Array.isArray(urls) || urls.length === 0) {
    return res.status(400).json({ error: 'URLs son obligatorias' });
  }

  try {
    const { analyzeCV, scoreJob } = require('./lib/claude');
    const { scrapeJobURL } = require('./lib/scraper');
    
    const analysis = await analyzeCV(cvBuf);
    const results = [];
    
    // Build scoring config
    const scoreCfg = {
      perfil: analysis,
      salarioMin: parseInt(req.body.salario) || 25000,
      ciudad: req.body.ciudad || 'Madrid',
      puestosRaw: analysis.titulo_profesional || '',
      priorities: { role: 8, salary: 7, location: 6, company: 5, skills: 7, growth: 5 }
    };

    for (const url of urls.slice(0, 10)) {
      try {
        const job = await scrapeJobURL(url);
        if (job) {
          const scored = await scoreJob(job, scoreCfg);
          results.push({ ...job, ...scored, url });
        }
      } catch (e) {
        results.push({ url, error: e.message });
      }
    }

    res.json({ results, cv_token: storeCvBuffer(cvBuf) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// START SERVER
// ══════════════════════════════════════════════════════════════════════════════

const PORT = process.env.PORT || 3000;

// Check if AI is configured on startup
const cfg = getConfig();

app.listen(PORT, () => {
  console.log(`\n╔════════════════════════════════════════════════════════════╗`);
  console.log(`║           JobRadarTest - Versión de Demostración           ║`);
  console.log(`╠════════════════════════════════════════════════════════════╣`);
  console.log(`║  Servidor iniciado en: http://localhost:${PORT}              ║`);
  console.log(`║  Estado: ${cfg?.provider ? 'Configurado (' + cfg.provider + ')' : 'Pendiente de configurar API'}          ║`);
  console.log(`╚════════════════════════════════════════════════════════════╝\n`);
});
